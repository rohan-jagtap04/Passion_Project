//
//  ContentView.swift
//  Mark Tracker
//
//  Created by Rohan Jagtap on 2020-09-01.
//  Copyright © 2020 Rohan Jagtap. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State var hello = ""
    var body: some View {
        
    TextField("Enter your password", text: $hello)
        
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

}
