//
//  MapView.swift
//  Mark Tracker
//
//  Created by Rohan Jagtap on 2020-09-04.
//  Copyright © 2020 Rohan Jagtap. All rights reserved.
//

import SwiftUI
import MapKit

struct MapView: UIViewRepresentable {
    func updateUIView(_ uiView: MapView.UIViewType, context: Context) {
        //
    }
    
    func makeUIView(context: Context) -> MKMapView  {
        MKMapView()
    }
    
    
}

struct MapView_Previews: PreviewProvider {
    static var previews: some View {
        MapView()
        .previewDevice(PreviewDevice(rawValue: "iPhone XS Max"))
    }
}
