//
//  Custom_TextField.swift
//  Mark Tracker
//
//  Created by Rohan Jagtap on 2020-09-04.
//  Copyright © 2020 Rohan Jagtap. All rights reserved.
//

import SwiftUI

struct Custom_TextField: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Custom_TextField_Previews: PreviewProvider {
    static var previews: some View {
        Custom_TextField()
    }
}
